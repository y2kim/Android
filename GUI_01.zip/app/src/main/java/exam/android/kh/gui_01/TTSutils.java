package exam.android.kh.gui_01;

import android.arch.lifecycle.Lifecycle;
import android.speech.tts.TextToSpeech;

public class TTSutils {

    public static TextToSpeech tts = null;
    //oncreat 되었을때

    String state = MainActivity.ACTIVITY_SERVICE;

}
