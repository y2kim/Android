package exam.android.kh.gui_01;

public class SpeechUtils {
    public static final  int  REQ_SPEECH_RECOGNIZE = 1000;
}
